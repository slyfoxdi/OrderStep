﻿using Microsoft.AspNetCore.Mvc;

namespace OrderStep.WebApi.Controllers
{
    public class AuthController : Controller
    {
        public AuthController()
        {

        }


        [HttpGet]
        public bool Health()
        {
            return true;
        }
    }
}
