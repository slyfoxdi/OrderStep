﻿using OrderStep.Domain.Extension.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderStep.Api.Intregration
{
    internal class AuthService
    {
        private readonly IHttpClientService _httpClientService;

        public AuthService(IHttpClientService httpClientService) {
            _httpClientService = httpClientService;
        }
    }
}
